<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "airline_management_system";
$con = new mysqli($servername, $username, $password, $dbname);
if ($con->connect_error) {
    die("Connection failed" . $con->connect_error);
}

$sid = $_REQUEST['SID'];
$sname = $_POST['name'];
$semail = $_POST['email'];
$scnic = $_POST['cnic'];
$saddress = $_POST['address'];
$sphone = $_POST['phone'];
$soccp = $_POST['occp'];

$sql = "UPDATE staff set Name = '$sname', Email = '$semail', CNIC = '$scnic', 
Address = '$saddress', Phone = '$sphone', Occupation = '$soccp'
where SID = $sid";

if ($con->query($sql) === true) {
    header("location:staff_display.php");
} else {
    echo "Error $sql <br> $con->error";
}

$con->close();
?>