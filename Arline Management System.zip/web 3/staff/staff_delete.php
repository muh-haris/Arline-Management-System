<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "airline_management_system";
    $con = new mysqli($servername, $username, $password, $dbname);
    if ($con->connect_error) {
        die("Connection failed" . $con->connect_error);
    }

    $id = $_REQUEST['SID'];
    $sql = "Delete from staff where SID = $id";
    if ($result = $con->query($sql)) {
        header("location:staff_display.php");
    } else {
        echo "Error $sql <br> $con->error";
    }
?>
