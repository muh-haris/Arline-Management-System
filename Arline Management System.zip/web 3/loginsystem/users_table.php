<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "airline_management_system";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    echo "Connected Successfully <br>";

    $sql = "Create table users(Serial_ID INT AUTO_INCREMENT PRIMARY KEY, 
    Username varchar(25), Password varchar(30), 
    Date_Time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP)";


    if($conn->query($sql) === TRUE) {
        echo "Users table created successfully";
    }
    else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
?>