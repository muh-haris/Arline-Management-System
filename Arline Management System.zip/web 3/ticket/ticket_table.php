<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "airline_management_system";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    echo "Connected Successfully <br>";

    $sql = "Create table ticket(Ticket_ID INT AUTO_INCREMENT PRIMARY KEY, 
    PassengerID INT, Airline varchar(25), Type varchar(20), 
    No_of_Tickets INT, Departure varchar(40), Destination varchar(40), 
    Date_Time DATETIME)";

    if($conn->query($sql) === TRUE) {
        echo "Ticket table created successfully";
    }
    else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
?>