<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "airline_management_system";
    $con = new mysqli($servername, $username, $password, $dbname);
    if ($con->connect_error) {
        die("Connection failed" . $con->connect_error);
    }

    $id = $_REQUEST['Ticket_ID'];
    $sql = "Delete from ticket where Ticket_ID = $id";
    if ($result = $con->query($sql)) {
        header("location:ticket_display.php");
    } else {
        echo "Error $sql <br> $con->error";
    }
?>
