<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "airline_management_system";
$con = new mysqli($servername, $username, $password, $dbname);
if ($con->connect_error) {
    die("Connection failed" . $con->connect_error);
}

$x = $_REQUEST['Ticket_ID'];
$sql = "select * from ticket where Ticket_ID = $x";
$result = $con->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    
    echo '
<head>
<title>Airline Management Form</title>
<style>
  body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
  }
  form {
    background-color: #fff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }
  table {
    width: 100%;
    border-collapse: collapse;
  }
  th {
    background-color: #4caf50;
    color: white;
    padding: 10px;
    text-align: center;
    font-size: 1.2em;
  }
  td {
    padding: 10px 50px;
    vertical-align: middle;
  }
  .row-1 th {
    background-color: #4caf50;
  }
  tr:nth-child(odd) {
    background-color: #f2f2f2;
  }
  td:first-of-type {
    color: #555;
  }
  input[type="text"],
  input[type="number"],
  input[type="datetime-local"],
  select {
    width: 100%;
    padding: 8px;
    margin: 4px 0;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
  }
  input[type="submit"] {
    background-color: #4caf50;
    color: white;
    padding: 10px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 1em;
  }
  input[type="submit"]:hover {
    background-color: #45a049;
  }
  #center {
    text-align: center;
  }
</style>
</head>

<body>';

echo "
<form action='./ticket_save.php?Ticket_ID=".$row["Ticket_ID"]."' method='post'>";

echo '
<table border="1">
<tr class="row-1">
  <th colspan="2">Ticket Updation Management System</th>
</tr>
<tr>
  <td><label for="pid">Passenger ID</label></td>
  <td><input type="number" name="pid" id="pid" required min="1" /></td>
</tr>
<tr>
  <td><label for="airline">Airline</label></td>
  <td>
    <select name="airline" id="airline" required
    value = '. $row["Airline"] .'>
      <option value=""></option>
      <option value="Emirates">Emirates</option>
      <option value="Qatar Airways">Qatar Airways</option>
      <option value="Qantas Airways">Qantas Airways</option>
      <option value="Eithad Airways">Eithad Airways</option>
      <option value="PIA">PIA</option>
      <option value="American Express">American Express</option>
      <option value="Turkish Airlines">Turkish Airlines</option>
    </select>
  </td>
</tr>
<tr>
  <td><label for="type">Type</label></td>
  <td>
    <select name="type" id="type" required
    value = '. $row["Type"] .'>
      <option value=""></option>
      <option value="Economic">Economic</option>
      <option value="First Class">First Class</option>
      <option value="Business">Business</option>
    </select>
  </td>
</tr>
<tr>
  <td><label for="no">No of Ticket/s</label></td>
  <td>
    <input
      type="number"
      name="no"
      id="no"
      min="0"
      max="10"
      value="1"
      required
      value = '. $row["No_of_Tickets"] .'
    />
  </td>
</tr>
<tr>
  <td><label for="dept">Departure City, Country</label></td>
  <td>
    <input
      type="text"
      name="dept"
      id="dept"
      placeholder="Lahore, Pakistan"
      required
      value = '. $row["Departure"] .'
    />
  </td>
</tr>
<tr>
  <td><label for="dest">Destination City, Country</label></td>
  <td>
    <input
      type="text"
      name="dest"
      id="dest"
      placeholder="London, England"
      required
      value = '. $row["Destination"] .'
    />
  </td>
</tr>
<tr>
  <td><label for="dnt">Date and Time</label></td>
  <td><input type="datetime-local" name="dnt" id="dnt" required 
  value = '. $row["Date_Time"] .'/></td>
</tr>
<tr>
  <td colspan="2" id="center">
    <input type="submit" value="Submit" />
  </td>
</tr>
</table>
</form>
</body>
    
';

} else {
    "Error $sql <br> $con->error";
}

$con->close();

?>
