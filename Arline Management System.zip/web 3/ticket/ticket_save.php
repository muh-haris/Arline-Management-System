<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "airline_management_system";
$con = new mysqli($servername, $username, $password, $dbname);
if ($con->connect_error) {
    die("Connection failed" . $con->connect_error);
}

$tid = $_REQUEST['Ticket_ID'];
$pid = $_POST['pid'];
$tairline = $_POST['airline'];
$ttype = $_POST['type'];
$tnot = $_POST['no'];
$tdept = $_POST['dept'];
$tdest=$_POST['dest'];
$tdnt=$_POST['dnt'];

$sql = "UPDATE ticket set PassengerID = $pid, Airline = '$tairline', 
Type = '$ttype', No_of_Tickets = '$tnot', Departure = '$tdept', 
Destination = '$tdest', Date_Time = '$tdnt'
where Ticket_ID = $tid";

if ($con->query($sql) === true) {
    header("location:ticket_display.php");
} else {
    echo "Error $sql <br> $con->error";
}

$con->close();
?>
