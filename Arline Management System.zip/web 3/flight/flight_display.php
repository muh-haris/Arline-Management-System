<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "airline_management_system";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    echo "Connected Successfully <br>";

    $sql = "SELECT * FROM flight";
    $result = $conn->query($sql);

    echo "
    <style>
        
        table {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            border-collapse: collapse;
            border: 0 solid gray;
        }
        td {
            padding: 10px;
        }
        .row-1 th {
            background-color: #4caf50;
            font-size: 1.5em;
        }
        th {
            background-color: yellowgreen;
            color: white;
            padding: 10px;
            text-align: center;
            font-size: 1.2em;
        }
        tr:nth-child(odd) {
            background-color: #f2f2f2;
        }
        a {
            text-decoration: none;
        }
    </style>

    <table border='1'>
        <tr class='row-1'>
            <th colspan='8'>Flight Management Table</th>
        </tr>
        <tr>
            <th>Flight ID</th>
            <th>Airline</th>
            <th>Type</th>
            <th>Departure City, Country</th>
            <th>Destination City, Country</th>
            <th>Date and Time</th>
            <th>Delete</th>
            <th>Edit</th>
        </tr>";

    if ($result->num_rows > 0) 
    {
        while($row = $result->fetch_assoc()) {

            $x= $row["FID"];
            echo "<tr>
                <td>" . $row['FID'] . "</td>
                <td>" . $row["Airline"] . "</td>
                <td>" . $row["Type"] . "</td>
                <td>" . $row["Departure"] . "</td>
                <td>" . $row["Destination"] . "</td>
                <td>" . $row["Date_Time"] . "</td>
                <td>" . "<a href='flight_delete.php?FID=$x'>Delete</a>" . "</td>
                <td>" . "<a href='flight_edit.php?FID=$x'>Edit</a>" . "</td>
            </tr>";
        }
    } 
    else {
        echo "0 results";
    }
    $conn->close();
?>
