<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "airline_management_system";
    $con = new mysqli($servername, $username, $password, $dbname);
    if ($con->connect_error) {
        die("Connection failed" . $con->connect_error);
    }

    $id = $_REQUEST['FID'];
    $sql = "Delete from flight where FID = $id";
    if ($result = $con->query($sql)) {
        header("location:flight_display.php");
    } else {
        echo "Error $sql <br> $con->error";
    }
?>
