<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "airline_management_system";
$con = new mysqli($servername, $username, $password, $dbname);
if ($con->connect_error) {
    die("Connection failed" . $con->connect_error);
}

$fid = $_REQUEST['FID'];
$fairline = $_POST['airline'];
$ftype = $_POST['type'];
$fdept = $_POST['dept'];
$fdest=$_POST['dest'];
$fdnt=$_POST['dnt'];

echo "$pid, $tairline, $ttype, $tnot, $tdest, $tdnt";

$sql = "UPDATE flight set Airline = '$fairline', Type = '$ftype',
Departure = '$fdept', Destination = '$fdest', Date_Time = '$fdnt'
where FID = $fid";

if ($con->query($sql) === true) {
    header("location:flight_display.php");
} else {
    echo "Error $sql <br> $con->error";
}

$con->close();
?>
