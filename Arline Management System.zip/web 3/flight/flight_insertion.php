<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "airline_management_system";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    echo "Connected Successfully <br>";

    $fairline = $_POST['airline'];
    $ftype = $_POST['type'];
    $fdept = $_POST['dept'];
    $fdest=$_POST['dest'];
    $fdnt=$_POST['dnt'];

    $sql = "INSERT INTO flight(Airline, Type, Departure, Destination, Date_Time)
    values ('$fairline', '$ftype', '$fdept', '$fdest', '$fdnt')";

    if($conn->query($sql) === TRUE) {
        echo "New flight record added successfully";
    }
    else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
?>
