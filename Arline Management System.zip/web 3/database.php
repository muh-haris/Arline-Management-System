<?php
    $servername = "localhost";
    $username = "root";
    $password = "";

    $con = new mysqli($servername, $username, $password);
    if ($con->connect_error) {
        die("Connection Failed" . $con->connect_error);
    } else {
        echo "Connected Successfully <br>";
    }

    $sql = "create database airline_management_system";
    if ($con->query($sql)) {
        echo "Database created successfully";
    } else {
        echo "Error $sql <br> $con->error";
    }
?>
