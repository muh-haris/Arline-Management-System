<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "airline_management_system";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    echo "Connected Successfully <br>";

    $sql = "Create table passenger(ID INT AUTO_INCREMENT PRIMARY KEY, 
    Name varchar(25), Email varchar(30) UNIQUE, CNIC varchar(20) UNIQUE, 
    Address varchar(40), Phone varchar(20))";

    if($conn->query($sql) === TRUE) {
        echo "Passenger table created successfully";
    }
    else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
?>