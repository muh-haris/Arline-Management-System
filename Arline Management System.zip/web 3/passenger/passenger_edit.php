<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "airline_management_system";
$con = new mysqli($servername, $username, $password, $dbname);
if ($con->connect_error) {
    die("Connection failed" . $con->connect_error);
}

$x = $_REQUEST['ID'];
$sql = "select * from passenger where ID = $x";
$result = $con->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    
    echo '
<head>
<title>Airline Management Form</title>
<style>
  body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
  }
  form {
    background-color: #fff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }
  table {
    width: 100%;
    border-collapse: collapse;
  }
  th {
    background-color: #4caf50;
    color: white;
    padding: 10px;
    text-align: center;
    font-size: 1.2em;
  }
  td {
    padding: 10px 50px;
    vertical-align: middle;
  }
  .row-1 th {
    background-color: #4caf50;
  }
  tr:nth-child(odd) {
    background-color: #f2f2f2;
  }
  td:first-of-type {
    color: #555;
  }
  input[type="text"],
  input[type="email"] {
    width: 100%;
    padding: 8px;
    margin: 4px 0;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
  }
  input[type="submit"] {
    background-color: #4caf50;
    color: white;
    padding: 10px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 1em;
  }
  input[type="submit"]:hover {
    background-color: #45a049;
  }
  #center {
    text-align: center;
  }
</style>
</head>

<body>';

echo "
<form action='./passenger_save.php?ID=".$row["ID"]."' method='post'>";

echo '
  <table border="1">
    <tr class="row-1">
      <th colspan="2">Passenger Updation Management System</th>
    </tr>
    <tr>
      <td><label for="pname">Name</label></td>
      <td><input type="text" name="name" id="pname" required 
      value = '. $row["Name"] .' /></td>
    </tr>
    <tr>
      <td><label for="pemail">Email</label></td>
      <td><input type="email" name="email" id="pemail" required 
      value = '. $row["Email"] .' /></td>
    </tr>
    <tr>
      <td><label for="pcnic">CNIC</label></td>
      <td><input type="text" name="cnic" id="pcnic" required 
      value = '. $row["CNIC"] .' /></td>
    </tr>
    <tr>
      <td><label for="paddress">Address</label></td>
      <td>
        <input type="text" name="address" id="paddress" required 
        value = '. $row["Address"] .' />
      </td>
    </tr>
    <tr>
      <td><label for="pphone">Phone</label></td>
      <td><input type="text" name="phone" id="pphone" required 
      value = '. $row["Phone"] .' /></td>
    </tr>
    <tr>
      <td colspan="2" id="center">
        <input type="submit" value="Submit" />
      </td>
    </tr>
  </table>
</form>
</body>
    
';

} else {
    "Error $sql <br> $con->error";
}

$con->close();

?>
