<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "airline_management_system";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    echo "Connected Successfully <br>";

    $sql = "SELECT * FROM passenger";
    $result = $conn->query($sql);

    echo "
    <style>
        
        table {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            border-collapse: collapse;
            border: 0 solid gray;
        }
        td {
            padding: 10px;
        }
        .row-1 th {
            background-color: #4caf50;
            font-size: 1.5em;
        }
        th {
            background-color: yellowgreen;
            color: white;
            padding: 10px;
            text-align: center;
            font-size: 1.2em;
        }
        tr:nth-child(odd) {
            background-color: #f2f2f2;
        }
        a {
            text-decoration: none;
        }
    </style>

    <table border='1'>
        <tr class='row-1'>
            <th colspan='8'>Passenger Management Table</th>
        </tr>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>CNIC</th>
            <th>Address</th>
            <th>Phone</th>
            <th>Delete</th>
            <th>Edit</th>
        </tr>";

    if ($result->num_rows > 0) 
    {
        while($row = $result->fetch_assoc()) {

            $x= $row["ID"];
            echo "<tr>
                <td>" . $row['ID'] . "</td>
                <td>" . $row["Name"] . "</td>
                <td>" . $row["Email"] . "</td>
                <td>" . $row["CNIC"] . "</td>
                <td>" . $row["Address"] . "</td>
                <td>" . $row["Phone"] . "</td>
                <td>" . "<a href='passenger_delete.php?ID=$x'>Delete</a>" . "</td>
                <td>" . "<a href='passenger_edit.php?ID=$x'>Edit</a>" . "</td>
            </tr>";
        }
    } 
    else {
        echo "0 results";
    }
    $conn->close();
?>
