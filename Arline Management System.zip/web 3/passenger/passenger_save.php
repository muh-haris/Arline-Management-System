<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "airline_management_system";
$con = new mysqli($servername, $username, $password, $dbname);
if ($con->connect_error) {
    die("Connection failed" . $con->connect_error);
}

$pid = $_REQUEST['ID'];
$pname = $_POST['name'];
$pemail = $_POST['email'];
$pcnic = $_POST['cnic'];
$paddress = $_POST['address'];
$pphone = $_POST['phone'];

$sql = "UPDATE passenger set Name = '$pname', Email = '$pemail',
CNIC = '$pcnic', Address = '$paddress', Phone = '$pphone'
where ID = $pid";

if ($con->query($sql) === true) {
    header("location:passenger_display.php");
} else {
    echo "Error $sql <br> $con->error";
}

$con->close();
?>
