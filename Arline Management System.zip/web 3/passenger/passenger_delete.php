<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "airline_management_system";
    $con = new mysqli($servername, $username, $password, $dbname);
    if ($con->connect_error) {
        die("Connection failed" . $con->connect_error);
    }

    $id = $_REQUEST['ID'];
    $sql = "Delete from passenger where ID = $id";
    if ($result = $con->query($sql)) {
        header("location:passenger_display.php");
    } else {
        echo "Error $sql <br> $con->error";
    }
?>
